﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Children
    {
        public Guid ChildrenID { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
}
