﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Job
    {
        public Guid JobID { get; set; }
        public int Salary { get; set; }
        public int hours { get; set; }


    }
}
