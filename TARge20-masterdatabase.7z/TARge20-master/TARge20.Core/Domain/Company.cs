﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Company
    {
        public Guid CompanyID { get; set; }
        public string contact { get; set; }
        public int RegistryCode { get; set; }
        
        public ICollection<Worker> Workers { get; set; }


    }
}
