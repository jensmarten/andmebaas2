﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class MedicalHistory
    {
        public Guid MedicalHistoryID { get; set; }
        public string GP { get; set; }
        public string Diseases { get; set; }
        public string Allergies { get; set; }

    }
}
