﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Access
    {
        public Guid AccessID { get; set; }
        public ICollection<AccessLevel> accessLevels { get; set; }

    }
}
