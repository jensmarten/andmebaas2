﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Requests
    {
        public Guid RequestsID { get; set; }
        public string Request { get; set; }
    }
}
