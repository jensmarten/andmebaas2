﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Worker
    {
        public Guid WorkerID { get; set; }
        public DateTime Startdate {get; set;}

        public string Name { get; set; }

        public DateTime Dateofbirth { get; set; }

        public int IDnumber { get; set; }

        public ICollection<Lending> Lendings { get; set; }

        public Job Jobs { get; set; }

        public ICollection<Children> Children { get; set; }

        public ICollection<Requests> Requests { get; set; }

        public ICollection<Access> Accesses { get; set; }

        public ICollection<SickLeave> SickLeaves { get; set; }

        public MedicalHistory MedicalHistorys { get; set; }



    }
}
