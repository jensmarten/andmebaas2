﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Lending
    {
        public Guid LendingID { get; set; }
        public DateTime DateOfLending { get; set; }

    }
}
