﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }

        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<Worker> Worker { get; set; }
        public DbSet<SickLeave> SickLeave { get; set; }
        public DbSet<Requests> Requests { get; set; }
        public DbSet<MedicalHistory> MedicalHistory { get; set; }
        public DbSet<Lending> Lending { get; set; }
        public DbSet<Job> Job { get; set; }
        public DbSet<Holiday> Holiday { get; set; }
        public DbSet<Company> Company { get; set; }
        public DbSet<Children> Children { get; set; }
        public DbSet<AccessLevel> accessLevel { get; set; }
        public DbSet<Access> Access { get; set; }

    }
}