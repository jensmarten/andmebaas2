﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class ERD : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    CompanyID = table.Column<Guid>(nullable: false),
                    contact = table.Column<string>(nullable: true),
                    RegistryCode = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.CompanyID);
                });

            migrationBuilder.CreateTable(
                name: "Holiday",
                columns: table => new
                {
                    HolidayID = table.Column<Guid>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    TotalDays = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Holiday", x => x.HolidayID);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                columns: table => new
                {
                    JobID = table.Column<Guid>(nullable: false),
                    Salary = table.Column<int>(nullable: false),
                    hours = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.JobID);
                });

            migrationBuilder.CreateTable(
                name: "MedicalHistory",
                columns: table => new
                {
                    MedicalHistoryID = table.Column<Guid>(nullable: false),
                    GP = table.Column<string>(nullable: true),
                    Diseases = table.Column<string>(nullable: true),
                    Allergies = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MedicalHistory", x => x.MedicalHistoryID);
                });

            migrationBuilder.CreateTable(
                name: "Worker",
                columns: table => new
                {
                    WorkerID = table.Column<Guid>(nullable: false),
                    Startdate = table.Column<DateTime>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Dateofbirth = table.Column<DateTime>(nullable: false),
                    IDnumber = table.Column<int>(nullable: false),
                    JobsJobID = table.Column<Guid>(nullable: true),
                    MedicalHistorysMedicalHistoryID = table.Column<Guid>(nullable: true),
                    CompanyID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Worker", x => x.WorkerID);
                    table.ForeignKey(
                        name: "FK_Worker_Company_CompanyID",
                        column: x => x.CompanyID,
                        principalTable: "Company",
                        principalColumn: "CompanyID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Worker_Job_JobsJobID",
                        column: x => x.JobsJobID,
                        principalTable: "Job",
                        principalColumn: "JobID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Worker_MedicalHistory_MedicalHistorysMedicalHistoryID",
                        column: x => x.MedicalHistorysMedicalHistoryID,
                        principalTable: "MedicalHistory",
                        principalColumn: "MedicalHistoryID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Access",
                columns: table => new
                {
                    AccessID = table.Column<Guid>(nullable: false),
                    WorkerID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Access", x => x.AccessID);
                    table.ForeignKey(
                        name: "FK_Access_Worker_WorkerID",
                        column: x => x.WorkerID,
                        principalTable: "Worker",
                        principalColumn: "WorkerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Children",
                columns: table => new
                {
                    ChildrenID = table.Column<Guid>(nullable: false),
                    DateOfBirth = table.Column<DateTime>(nullable: false),
                    WorkerID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Children", x => x.ChildrenID);
                    table.ForeignKey(
                        name: "FK_Children_Worker_WorkerID",
                        column: x => x.WorkerID,
                        principalTable: "Worker",
                        principalColumn: "WorkerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Lending",
                columns: table => new
                {
                    LendingID = table.Column<Guid>(nullable: false),
                    DateOfLending = table.Column<DateTime>(nullable: false),
                    WorkerID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lending", x => x.LendingID);
                    table.ForeignKey(
                        name: "FK_Lending_Worker_WorkerID",
                        column: x => x.WorkerID,
                        principalTable: "Worker",
                        principalColumn: "WorkerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Requests",
                columns: table => new
                {
                    RequestsID = table.Column<Guid>(nullable: false),
                    Request = table.Column<string>(nullable: true),
                    WorkerID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Requests", x => x.RequestsID);
                    table.ForeignKey(
                        name: "FK_Requests_Worker_WorkerID",
                        column: x => x.WorkerID,
                        principalTable: "Worker",
                        principalColumn: "WorkerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SickLeave",
                columns: table => new
                {
                    SickLeaveID = table.Column<Guid>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    TotalDays = table.Column<int>(nullable: false),
                    WorkerID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SickLeave", x => x.SickLeaveID);
                    table.ForeignKey(
                        name: "FK_SickLeave_Worker_WorkerID",
                        column: x => x.WorkerID,
                        principalTable: "Worker",
                        principalColumn: "WorkerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "accessLevel",
                columns: table => new
                {
                    AccessLevelID = table.Column<Guid>(nullable: false),
                    Level1 = table.Column<int>(nullable: false),
                    Level2 = table.Column<int>(nullable: false),
                    Level3 = table.Column<int>(nullable: false),
                    AccessID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_accessLevel", x => x.AccessLevelID);
                    table.ForeignKey(
                        name: "FK_accessLevel_Access_AccessID",
                        column: x => x.AccessID,
                        principalTable: "Access",
                        principalColumn: "AccessID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Access_WorkerID",
                table: "Access",
                column: "WorkerID");

            migrationBuilder.CreateIndex(
                name: "IX_accessLevel_AccessID",
                table: "accessLevel",
                column: "AccessID");

            migrationBuilder.CreateIndex(
                name: "IX_Children_WorkerID",
                table: "Children",
                column: "WorkerID");

            migrationBuilder.CreateIndex(
                name: "IX_Lending_WorkerID",
                table: "Lending",
                column: "WorkerID");

            migrationBuilder.CreateIndex(
                name: "IX_Requests_WorkerID",
                table: "Requests",
                column: "WorkerID");

            migrationBuilder.CreateIndex(
                name: "IX_SickLeave_WorkerID",
                table: "SickLeave",
                column: "WorkerID");

            migrationBuilder.CreateIndex(
                name: "IX_Worker_CompanyID",
                table: "Worker",
                column: "CompanyID");

            migrationBuilder.CreateIndex(
                name: "IX_Worker_JobsJobID",
                table: "Worker",
                column: "JobsJobID");

            migrationBuilder.CreateIndex(
                name: "IX_Worker_MedicalHistorysMedicalHistoryID",
                table: "Worker",
                column: "MedicalHistorysMedicalHistoryID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "accessLevel");

            migrationBuilder.DropTable(
                name: "Children");

            migrationBuilder.DropTable(
                name: "Holiday");

            migrationBuilder.DropTable(
                name: "Lending");

            migrationBuilder.DropTable(
                name: "Requests");

            migrationBuilder.DropTable(
                name: "SickLeave");

            migrationBuilder.DropTable(
                name: "Access");

            migrationBuilder.DropTable(
                name: "Worker");

            migrationBuilder.DropTable(
                name: "Company");

            migrationBuilder.DropTable(
                name: "Job");

            migrationBuilder.DropTable(
                name: "MedicalHistory");
        }
    }
}
